﻿<#
Disclaimer:
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.

THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  

We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object code form of the Sample Code,
provided that you agree: 
       (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
       (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and 
       (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the Sample Code.

Please note: None of the conditions outlined in the disclaimer above will supersede the terms and conditions contained within the Premier Customer Services Description.
#>
# Bring in Supporting Function to convert Key properties from DSREGCMD
# to a PowerShell Object as well as common variables to both scripts
function Get-DSRegStatus {
       $Result = (dsregcmd.exe /status | Select-String -Pattern '(AzureADJoined : )|(DomainJoined : )|(WorkplaceJoined : )')
       $DSRegStatus = New-Object PSCustomobject
       Foreach ($i in $result) { 
              $property = $i.matches[0].value.replace(':', '').trim()
              $value = $i.line.substring($i.matches[0].index + $i.matches[0].length)
              $DSRegStatus | Add-member -MemberType NoteProperty -Name $property -Value $value
       }
       Return $DSRegStatus
}
function Test-VPN {
       $VPNTest = Get-WmiObject -Query "Select Name,NetEnabled from Win32_NetworkAdapter where (Name like '%AnyConnect%' or Name like '%VPN%') and NetEnabled='True'"
       return [bool]$VPNTest
   }
   
$TempStatusFolder = "$($ENV:ProgramData)\SSC\DualState"
$StatusFile = "$TempStatusFolder\3-WaitForVPNAndJoin.txt"
$JoinStatusFile = "$TempStatusFolder\3-Join.txt"


# trap for VPN
while (!(Test-VPN))
{
Start-Sleep 30
}


# Force Join to AzureAD 
New-Item -ItemType File -Path $JoinStatusFile -Force -erroraction SilentlyContinue
DSREGCMD.EXE /join /debug > $JoinStatusFile

$Status=Get-DSRegStatus

New-Item -ItemType File -Path $StatusFile -erroraction SilentlyContinue | Out-Null
$StatusMesssage = "System reconnected to tenant. - Système reconnecté au locataire."
Add-Content -Path $StatusFile -Value $StatusMesssage
$Status | ConvertFrom-Json | Add-Content -Path $StatusFile
whoami >> $StatusFile
