﻿<#
Disclaimer:
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.

THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  

We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object code form of the Sample Code,
provided that you agree: 
       (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
       (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and 
       (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the Sample Code.

Please note: None of the conditions outlined in the disclaimer above will supersede the terms and conditions contained within the Premier Customer Services Description.
#>
# Common folder with ReadWrite access to Users and System
function Get-DSRegStatus {
       $Result = (dsregcmd.exe /status | Select-String -Pattern '(AzureADJoined : )|(DomainJoined : )|(WorkplaceJoined : )')
       $DSRegStatus = New-Object PSCustomobject
       Foreach ($i in $result) { 
           $property = $i.matches[0].value.replace(':', '').trim()
           $value = $i.line.substring($i.matches[0].index + $i.matches[0].length)
           $DSRegStatus | Add-member -MemberType NoteProperty -Name $property -Value $value
       }
       Return $DSRegStatus
   }
   
$TempStatusFolder = "$($ENV:ProgramData)\SSC\DualState"
$ScriptLocation = Split-Path $PSCommandPath

# File name to be dropped to indicate successful process
$StatusFile = "$($TempStatusFolder)\1-DSRegCMD-Leave.txt"
$LeaveStatusFile = "$($TempStatusFolder)\1-Leave.txt"

$Status=Get-DSRegStatus

# Enable policies to prevent auto join of Workplace
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WorkplaceJoin -Name BlockAADWorkplaceJoin -Value 1 -PropertyType Dword -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WorkplaceJoin -Name autoWorkplaceJoin -Value 1 -PropertyType Dword -Force
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\WorkplaceJoin -Name Recovery-Check -Value 1 -PropertyType Dword -Force

# Leave Azure AD 
New-Item -ItemType File -Path $LeaveStatusFile -Force -erroraction SilentlyContinue
DSREGCMD.exe /leave /debug > $LeaveStatusFile

# Status Message - should be en Francais and English
$StatusMessage = 'System Removed from AzureAD'

# Create file and Add on status to file
New-Item -Itemtype File -path $StatusFile -force -erroraction silentlycontinue | Out-Null
Add-Content -Path $StatusFile -Value $StatusMessage -Encoding UTF8
$JSonStatus = ($Status | ConvertTo-Json)
Add-Content -path $StatusFile -value $JSonStatus
whoami >> $StatusFile

