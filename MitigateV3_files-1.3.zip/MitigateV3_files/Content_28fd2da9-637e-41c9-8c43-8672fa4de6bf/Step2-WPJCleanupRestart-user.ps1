﻿<#
Disclaimer:
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.

THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  

We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object code form of the Sample Code,
provided that you agree: 
       (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
       (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and 
       (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the Sample Code.

Please note: None of the conditions outlined in the disclaimer above will supersede the terms and conditions contained within the Premier Customer Services Description.
#>
# Common folder with ReadWrite access to Users and System
function Get-DSRegStatus {
       $Result = (dsregcmd.exe /status | Select-String -Pattern '(AzureADJoined : )|(DomainJoined : )|(WorkplaceJoined : )')
       $DSRegStatus = New-Object PSCustomobject
       Foreach ($i in $result) { 
           $property = $i.matches[0].value.replace(':', '').trim()
           $value = $i.line.substring($i.matches[0].index + $i.matches[0].length)
           $DSRegStatus | Add-member -MemberType NoteProperty -Name $property -Value $value
       }
       Return $DSRegStatus
   }
   
   $TempStatusFolder = "$($ENV:ProgramData)\SSC\DualState"
$ScriptLocation = Split-Path $PSCommandPath

# File name to be dropped to indicate successful process
$StatusFile = "$($TempStatusFolder)\2-WPJCleanup.txt"
$ErrorFile = "$($TempStatusFolder)\2-WPJError.txt"

$Status=Get-DSRegStatus

# Store away current folder
Push-Location
Set-Location -Path $ScriptLocation

# Store away current folder
Push-Location

# Older Dos App, Ensure we are in the folder's context
if (!(Test-Path "$($Env:ProgramData)\SSC\DualState\WPJCleanup"))
{
    Copy-Item -path .\WPJCleanup -destination "$($Env:ProgramData)\SSC\DualState\WPJCleanup" -recurse -erroraction SilentlyContinue
}
Set-Location -path "$($Env:ProgramData)\SSC\DualState\WPJCleanup"
Remove-item .\output.txt -force -erroraction silentlycontinue | Out-Null
.\WPJCleanUp.cmd
Remove-Item 'HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WorkplaceJoin\' -Recurse -Force

Pop-Location
Pop-Location
$Status=Get-DSRegStatus

If ($status.WorkplaceJoined -eq 'NO' -or $status.Workplacejoined -eq '')
{
# Status Message - should be en Francais and English
$StatusMessage = 'WPJCleanup completed'

# Create file and Add on status to file
New-Item -Itemtype File -path $StatusFile -force -erroraction silentlycontinue | Out-Null
Add-Content -Path $StatusFile -Value $StatusMessage -Encoding UTF8
$JSonStatus = ($Status | ConvertTo-Json)
Add-Content -path $StatusFile -value $JSonStatus
WhoamI >> $StatusFile

# Pass back exit code for a restart to Configuration Manager
# Exit does not work and call produce an error in Configuration Manager
[System.Environment]::Exit(1641)
}
else {
Write-Verbose 'Leave Failed'
New-Item -Itemtype File -path $ErrorFile -force -erroraction silentlycontinue | Out-Null
Add-Content -Path $ErrorFile -Value 'Leave Failed' -Encoding UTF8
$JSonStatus = ($Status | ConvertTo-Json)
Add-Content -path $ErrorFile -value $JSonStatus
WhoamI >> $ErrorFile

}