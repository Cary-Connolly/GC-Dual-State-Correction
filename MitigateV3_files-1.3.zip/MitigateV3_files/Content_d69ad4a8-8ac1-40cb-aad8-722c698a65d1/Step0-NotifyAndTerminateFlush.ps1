﻿<#
Disclaimer:
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.

THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  

We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object code form of the Sample Code,
provided that you agree: 
       (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
       (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and 
       (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the Sample Code.

Please note: None of the conditions outlined in the disclaimer above will supersede the terms and conditions contained within the Premier Customer Services Description.
#>
function Get-DSRegStatus {
    $Result = (dsregcmd.exe /status | Select-String -Pattern '(AzureADJoined : )|(DomainJoined : )|(WorkplaceJoined : )')
    $DSRegStatus = New-Object PSCustomobject
    Foreach ($i in $result) { 
        $property = $i.matches[0].value.replace(':', '').trim()
        $value = $i.line.substring($i.matches[0].index + $i.matches[0].length)
        $DSRegStatus | Add-member -MemberType NoteProperty -Name $property -Value $value
    }
    Return $DSRegStatus
}

$Status = Get-DSRegStatus

$TempStatusFolder = "$($ENV:ProgramData)\SSC\DualState"
$ScriptLocation = Split-Path $PSCommandPath
$StatusFile = "$TempStatusFolder\0-NotifyandFlushData.txt"

$s = new-object -comobject wscript.shell

$Notification = @"
To be able to complete  the upcoming M365 mailbox move, we must resolve an issue with your computer.  This process should take approximately 5 minutes.  

Before clicking “Ok” please save and close your work and make sure you are connected to secure remote access (i.e. VPN).  During this process your computer will restart. After the restart, please re-connect to VPN before opening any other applications.


Pour être en mesure de compléter la prochaine migration de la boîte aux lettres vers M365, nous devons régler un problème avec votre ordinateur. Ce processus devrait prendre environ 5 minutes.  

Avant de cliquer sur « OK », veuillez enregistrer votre travail et le fermer, et vous assurer que vous êtes connecté à un accès à distance sécurisé (c’est-à-dire RPV). Au cours de ce processus, votre ordinateur redémarrera. Après le redémarrage, veuillez vous reconnecter au RPV avant d’ouvrir toute autre application.
"@

$s.popup($Notification, 0, 'Dual State Fix', 4160) | Out-Null

$statusmessage = "User Clicked OK or Closed box as acknowledgement to start remediation - L'utilisateur a cliqué sur OK ou sur la case fermée comme accusé de réception pour démarrer la correction"

# Terminate Browsers and flush cache / cookies

Get-Process *Edge* | Stop-Process -force -Confirm:$False
# Clear Cache for Edge Chromium
Get-ChildItem "$($ENV:LocalAppData)\Microsoft\Edge\User Data" -Recurse -Include *cookie* -force -erroraction silentlycontinue | Remove-Item -Recurse -confirm:$False -force -ErrorAction SilentlyContinue
Get-ChildItem "$($ENV:LocalAppData)\Microsoft\Edge\User Data" -Recurse -Include *cache* -force -erroraction silentlycontinue | Remove-Item -Recurse -confirm:$False -force -ErrorAction SilentlyContinue
    
# Clear Cache for Legacy Edge
Get-ChildItem "$($ENV:LocalAppData)\Packages\Microsoft.MicrosoftEdge_*\AC\" -Recurse -Include '#!*' -directory -Force -erroraction silentlycontinue | Remove-Item -Recurse -confirm:$False -force -ErrorAction SilentlyContinue
    
Get-Process *Chrome* | Stop-Process -force -Confirm:$False
    
# Clear Cache for Chrome
Get-ChildItem "$($ENV:LocalAppData)\Google\Chrome\User Data" -Recurse -Include *cookie* -Force -erroraction silentlycontinue | Remove-Item -Recurse -confirm:$False -force -ErrorAction SilentlyContinue
Get-ChildItem "$($ENV:LocalAppData)\Google\Chrome\User Data" -Recurse -Include *cache* -Force -erroraction silentlycontinue | Remove-Item -Recurse -confirm:$False -force -ErrorAction SilentlyContinue
    
Get-Process *Iexplore* | Stop-Process -force -Confirm:$False
    
# Clear Cache for Internet Explorer
RunDll32.exe InetCpl.cpl, ClearMyTracksByProcess 2
RunDll32.exe InetCpl.cpl, ClearMyTracksByProcess 8
    
# Terminate Teams - Flush Roaming 

#Stop Teams process 
do {
    $ProcessTeams = Get-Process -ProcessName Teams -ErrorAction SilentlyContinue 
    $ProcessTeams | Stop-Process -Force -erroraction SilentlyContinue
}
until ($NULL -eq $ProcessTeams)
Write-Verbose "Teams Process Sucessfully Stopped" 

#Clear Team Cache
try {
    Get-ChildItem -Path "$($env:APPDATA)\Microsoft\teams\blob_storage" -erroraction silentlycontinue | Remove-Item -Recurse -ErrorAction SilentlyContinue
    Get-ChildItem -Path "$($env:APPDATA)\Microsoft\teams\databases" -erroraction silentlycontinue | Remove-Item -Recurse -ErrorAction SilentlyContinue
    Get-ChildItem -Path "$($env:APPDATA)\Microsoft\teams\cache" -erroraction silentlycontinue | Remove-Item -Recurse -ErrorAction SilentlyContinue
    Get-ChildItem -Path "$($env:APPDATA)\Microsoft\teams\gpucache" -erroraction silentlycontinue | Remove-Item -Recurse -ErrorAction SilentlyContinue
    Get-ChildItem -Path "$($env:APPDATA)\Microsoft\teams\Indexeddb" -erroraction silentlycontinue | Remove-Item -Recurse -ErrorAction SilentlyContinue
    Get-ChildItem -Path "$($env:APPDATA)\Microsoft\teams\Local Storage" -erroraction silentlycontinue | Remove-Item -Recurse -ErrorAction SilentlyContinue
    Get-ChildItem -Path "$($env:APPDATA)\Microsoft\teams\tmp" -erroraction silentlycontinue | Remove-Item -Recurse -ErrorAction SilentlyContinue
    Write-Verbose "Teams Cache Cleaned" 
}
catch {
    Write-Verbose $_ 
}

#Remove Credential from Credential manager
(cmdkey /list | ForEach-Object { if ($_ -like "*Target:*" -and $_ -like "*msteams*") { cmdkey /del:($_ -replace " ", "" -replace "Target:", "") } }) | Out-Null

#Remove Reg.Key
$Regkeypath = "HKCU:\Software\Microsoft\Office\Teams" 
$value = $NULL -eq (Get-ItemProperty $Regkeypath -erroraction silentlycontinue).HomeUserUpn
If ($value -eq $False) { 
    Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Office\Teams" -Name "HomeUserUpn" -erroraction SilentlyContinue
    Write-Verbose "The registry value Sucessfully removed" 
} 
Else { Write-Verbose "The registry value does not exist" }

#Get Desktop-config.json
$TeamsFolders = "$env:APPDATA\Microsoft\teams"
try {
    $SourceDesktopConfigFile = "$TeamsFolders\desktop-config.json"
    $desktopConfig = (Get-Content -Path $SourceDesktopConfigFile -erroraction stop | ConvertFrom-Json)
}
catch { Write-Verbose "Failed to open Desktop-config.json" }

#Overwrite the desktop-config.json
Write-Verbose "Modify desktop-Config.Json"
try {
    $desktopConfig.isLoggedOut = $true
    $desktopConfig.upnWindowUserUpn = ""; #The email used to sign in
    $desktopConfig.userUpn = "";
    $desktopConfig.userOid = "";
    $desktopConfig.userTid = "";
    $desktopConfig.homeTenantId = "";
    $desktopConfig.webAccountId = "";

    # Prevent Automatic Start of Teams Application
    $desktopConfig.OpenasHidden = $False
    $desktopConfig.OpenatLogin = $False
    $desktopConfig.RunningOnClose = $False

    # Update Teams Configuration
    $desktopConfig | ConvertTo-Json -Compress | Set-Content -Path $SourceDesktopConfigFile -Force
}
catch { Write-Verbose "Failed to overwrite desktop-config.json" }
Write-Verbose "Modify desktop-Config.Json - Finished"

#Delete the Cookies file. This is a fix for when the joining as anonymous, and prevents the last used guest name from being reused.
Get-ChildItem "$TeamsFolders\Cookies" -erroraction silentlycontinue | Remove-Item -recurse -force -erroraction silentlycontinue

#Lastly delete the storage.json, this corrects some error that MSTeams otherwise would have when logging in again.
Get-ChildItem "$TeamsFolders\storage.json" -erroraction silentlycontinue | Remove-Item -recurse -force -erroraction silentlycontinue

#Try to remove the Link School/Work account if there was one. It can be created if the first time you sign in, the user all
$LocalPackagesFolder = "$env:LOCALAPPDATA\Packages"
$AADBrokerFolder = Get-ChildItem -Path $LocalPackagesFolder -Recurse -Include "Microsoft.AAD.BrokerPlugin_*";
$AADBrokerFolder = $AADBrokerFolder[0];
Get-ChildItem "$AADBrokerFolder\AC\TokenBroker\Accounts" | Remove-Item -Recurse -Force

$statusmessage= "Internet cookies and cache flushed for 'Internet Explorer', 'Chrome', 'Edge' and 'Edge Chromium' - Cookies Internet et cache rincés pour 'Internet Explorer', 'Chrome', 'Edge' et 'Edge Chromium', Teams terminated and data flushed"
New-Item -itemtype File -path $StatusFile -force -ErrorAction Stop | Out-Null
Add-Content -path $StatusFile -value $statusmessage
$JSonStatus = ($Status | ConvertTo-Json)
Add-Content -path $StatusFile -value $JSonStatus
whoami >> $StatusFile
