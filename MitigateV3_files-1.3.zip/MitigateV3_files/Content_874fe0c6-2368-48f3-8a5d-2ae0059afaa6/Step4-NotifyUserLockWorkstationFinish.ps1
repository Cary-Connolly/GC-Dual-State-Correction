﻿<#
Disclaimer:
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.

THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  

We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object code form of the Sample Code,
provided that you agree: 
       (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; 
       (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and 
       (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the Sample Code.

Please note: None of the conditions outlined in the disclaimer above will supersede the terms and conditions contained within the Premier Customer Services Description.
#>
function Get-DSRegStatus {
       $Result = (dsregcmd.exe /status | Select-String -Pattern '(AzureADJoined : )|(DomainJoined : )|(WorkplaceJoined : )')
       $DSRegStatus = New-Object PSCustomobject
       Foreach ($i in $result) { 
              $property = $i.matches[0].value.replace(':', '').trim()
              $value = $i.line.substring($i.matches[0].index + $i.matches[0].length)
              $DSRegStatus | Add-member -MemberType NoteProperty -Name $property -Value $value
       }
       Return $DSRegStatus
}

$TempStatusFolder = "$($ENV:ProgramData)\SSC\DualState"
$ScriptLocation = Split-Path $PSCommandPath

$StatusFile = "$($TempStatusFolder)\4-NotifyUserFinalWork.txt"
$ErrorFile = "$($TempStatusFolder)\4-Error.txt"

$Status = Get-DSRegStatus

If ($Status.WorkplaceJoined -eq 'NO' -or $Status.Workplacejoined -eq '') {
       # Bring in Supporting Function to convert Key properties from DSREGCMD
       # to a PowerShell Object as well as common variables to both scripts
       # Common folder with ReadWrite access to Users and System

       # Simple script targeted User context to notify user of intended work
       $s = new-object -comobject wscript.shell

$Notification = @"
The changes to your computer are nearly complete.  When you click ‘Ok’ your computer will be locked and you will need to enter your password. To do this, use Ctrl-Alt-Del.  Please use your @dept.gc.ca account and the password you use to log into Microsoft Teams.  After unlocking your computer you can continue to work as usual.

Les changements apportés à votre ordinateur sont presque terminés. Lorsque vous cliquez sur « OK », votre serez verrouillé et vous devrez entrer votre mot de passe. Pour ce faire, appuyez sur Ctrl-Alt-Del. Veuillez utiliser votre compte @ministère.gc.ca et le mot de passe que vous utilisez pour vous connecter à Microsoft Teams. Après avoir déverrouillé votre ordinateur, vous pouvez continuer à travailler comme d’habitude.
"@

       $s.popup($Notification, 0, 'Dual State Fix', 4160)

       rundll32.exe user32.dll, LockWorkStation
       # Restart Office Portal for User to login in
       Start-Process MSEdge -ArgumentList 'https://portal.office.com'

       #Get Desktop-config.json
       $TeamsFolders = "$env:APPDATA\Microsoft\teams"
       try {
              $SourceDesktopConfigFile = "$TeamsFolders\desktop-config.json"
              $desktopConfig = (Get-Content -Path $SourceDesktopConfigFile | ConvertFrom-Json)
       }
       catch { Write-Output "Failed to open Desktop-config.json" }

       #Overwrite the desktop-config.json
       Write-Output "Modify desktop-Config.Json"
       try {
              # Enable Automatic Start of Teams Application
              $desktopConfig.OpenasHidden = $False
              $desktopConfig.OpenatLogin = $True
              $desktopConfig.RunningOnClose = $True

              # Update Teams Configuration
              $desktopConfig | ConvertTo-Json -Compress | Set-Content -Path $SourceDesktopConfigFile -Force
       }
       catch { Write-Output "Failed to overwrite desktop-config.json" }
       Write-Output "Modify desktop-Config.Json - Finished"

       New-Item -ItemType File -Path $StatusFile
       $StatusMesssage = "User Clicked OK or Closed box as acknowledgement complete fix - LL'utilisateur a cliqué sur OK ou sur la case fermée comme solution de confirmation"
       Add-Content -Path $StatusFile -Value $StatusMesssage
       $Status | ConvertTo-Json | Add-Content -Path $StatusFile
       whoami >> $StatusFile
}
else {
       Write-verbose 'Device Still Workplace Joined'
       New-Item -ItemType File -Path $ErrorFile
       $ErrorMesssage = "Device Still Workplace Joined"
       Add-Content -Path $ErrorFile -Value $ErrorMesssage
       $Status | ConvertTo-Json | Add-Content -Path $ErrorFile
       whoami >> $ErrorFile

}
